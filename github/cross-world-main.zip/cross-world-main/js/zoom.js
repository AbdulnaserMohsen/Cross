$(document).ready(function(){
  $(".zoom").zoom();
});
